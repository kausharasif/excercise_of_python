import math
import os 
import sys 
def GetFunctionList(ModuleName):
    list = dir(ModuleName)
    print(f"function is {ModuleName}")
    for item in list:
        print(item)
GetFunctionList(math)
GetFunctionList(os)
GetFunctionList(sys)
