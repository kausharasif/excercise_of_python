import random  as rd 
def generateotp(length=6):
    count=1
    otp=''
    while count<=length:
        otp= otp + str(rd.randint(0,9))
        count+=1
    return otp    
otp = generateotp() #6 digits 
print(otp)
otp = generateotp(10) #6 digits 
print(otp)
otp = generateotp(20) #6 digits 
print(otp)