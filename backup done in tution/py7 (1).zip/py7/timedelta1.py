from datetime import timedelta,date,datetime

print(timedelta(days=365))
print("After 1 year date" + str(datetime.now() + timedelta(days=365)))
print("After 6 month date" + str(datetime.now() + timedelta(days=180)))
print("before 84 days date" + str(datetime.now() - timedelta(days=84)))