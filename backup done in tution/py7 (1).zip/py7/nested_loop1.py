#write a program to findout armstrong between given range
'''
first = 100
last = 200

'''
import math 
#in built module it same as #include<maths.h>
first = int(input("Enter first number"))
last = int(input("Enter last number"))

number = first
counter=1
while number<=last: #outer loop
    exponent = len(str(number))
    total=0
    copy_number = number

    while number>0: #inner loop 
        reminder = number%10 #3
        temp = math.pow(reminder,exponent) #27
        total+=temp # 27
        number = int(number/10) # 15

    if copy_number==total:
        print(f"{copy_number} ")
    number=first+counter
    counter=counter+1