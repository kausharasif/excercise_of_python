#write a program to create new file and write content into it 
file_name = input("Enter new file name to create it..")
file = open(file_name,"a")
print("File created.... ")
content = input("enter content to write into file...")
file.write(content)
print("Content written into file... ")
file.close()