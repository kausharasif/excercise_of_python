numbers = ['Ankit','Hanish','Parth']
sum=0
count=0
for value in numbers:
    try:
        sum=sum+value
        count=count+1
    except TypeError:
        print(f"this value {value} is invalid hence skiped")
    print(value,end=' ')
    print("")
try:
    average = sum/count
    print(f"sum = {sum} average = {average}")
except ZeroDivisionError:
    print("list is either empty or all values are invalid")