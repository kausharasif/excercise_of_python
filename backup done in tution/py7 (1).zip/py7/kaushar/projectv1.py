from DBOperation import MyDatabase 
db1 = MyDatabase(database='kaushar',script=__file__)
while 1:
    print('-'*100)
    print("Press 1 for Bill management")
    print("Press 2 for Product management")
    print("Press 0 for for exit")
    ModuleChoice = int(input("enter your choice "))
    if ModuleChoice==1:
        while 1:
            print("Press 1 to Add product into bill")
            print("Press 2 to delete product from bill")
            print("Press 3 to view bill items of current bill")
            print("Press 4 to save & print bill")
            print("Press 5 to print bills between given dates")
            print("Press 6 to search for specific bill by name")
            print("Press 0 for for exit")
            BillChoice = int(input("enter your choice "))
            if BillChoice==1: 
                print("here we Add product into bill")
            elif BillChoice==2: 
                print("here we delete product from bill")
            elif BillChoice==3: 
                print("here we view bill items")
            elif BillChoice==4: 
                print("here we save & print bill")
            elif BillChoice==5: 
                print("here we print bills between given dates")
            elif BillChoice==6: 
                print("here we search for specific bill by name")
            elif BillChoice==0:
                break #it will break to outer while loop 
            else:
                print("Invalid choice")
    elif ModuleChoice==2:
        while 1:
            print("Press 1 to Add new product")
            print("Press 2 to Update product")
            print("Press 3 to delete product")
            print("Press 4 to view all product")
            print("Press 0 for for exit")
            ProductChoice = int(input("enter your choice "))
            if ProductChoice==1: 
                print("here we will add new product")
            elif ProductChoice==2: 
                print("here we will update product")
            elif ProductChoice==3: 
                print("here we will delete product")
            elif ProductChoice==4: 
                print("here we will display all product")
            elif ProductChoice==0:
                break #it will break to outer while loop 
            else:
                print("Invalid choice")
    elif ModuleChoice==0:
        print("Good Bye")
        print('-'*100)
        break
    else:
        print("Invalid choice")
    
