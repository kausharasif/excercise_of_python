import datetime
from datetime import date
def ConvertDatetoYMD(mydate):
    converted_date = datetime.datetime.strptime(
        mydate, "%d/%m/%Y").strftime("%Y-%m-%d")
    return converted_date
def ConvertDatetoDMY(mydate):
    converted_date = datetime.datetime.strptime(
        mydate, "%Y-%m-%d").strftime("%d/%m/%Y")
    return converted_date
def getCurrentDate():
    current_date = date.today()
    month = str(current_date.month)
    if len(month)==1:
        month = "0" + month
    indian_format_date = str(current_date.day) + "/" + \
        str(month) + "/" + str(current_date.year)
    return indian_format_date
# 01print(ConvertDatetoYMD('19/01/2022'))
# print(ConvertDatetoDMY('2022-12-31'))
#print(getCurrentDate())