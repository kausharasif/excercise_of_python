from DBOperation import MyDatabase 
import date_conversion as dc
mydb = MyDatabase(database='kaushar',script=__file__)
def DisplayProduct():
    sql = "select * from product where isDeleted=0"
    table = mydb.FetchRow(sql)
    if table==False:
        print("Error occured.")
    else:
        heading = f"{'id':2}|{'name':32}{'detail':73}{'stock':12}{'price':12}"
        print(heading)
        for row in table:
            print('_'*150)
            output =  f"{row['id']:2}|{row['name']:32}{row['detail']:64}{row['stock']:12}{row['price']:12}"
            print(output)
        print('_'*150)
def GetProductById(productid):
    sql = "select price,stock from product where isDeleted=0 and id=%s"
    values = [productid]
    table = mydb.FetchRow(sql,values)
    return table
def GetItemById(itemid):
    #used to get id from bill_product table
    sql = "select id from bill_product where billid=0 and id=%s"
    values = [itemid]
    table = mydb.FetchRow(sql,values)
    return len(table)
def DisplayBillItems():
    sql = "select name,b.id 'itemid',quantity,rate from product p,bill_product b where billid=0 and productid=p.id order by b.id"
    table = mydb.FetchRow(sql)
    if table==False:
        print("Error occured.")
    else:
        heading = f"{'item id':7}|{'        rate':12}|{'    quantity':12}|{'       total':12}|{'name':32}"
        print(heading)
        total=0
        for row in table:
            print('_'*150)
            itemtotal = row['rate'] * row['quantity']
            output =  f"{row['itemid']:7}|{row['rate']:12}|{row['quantity']:12}|{itemtotal:12}|{row['name']:32}"
            print(output)
            total+= itemtotal
        print('_'*150)
        print(f"total bill amount {total}")
        print('_'*150)
def get_bill(table):
    if table==False:
        print("Error occured.")
    else:
        heading = f"{'bill no':7}|{'name':64}|{'date':16}|{'amount':12}|{'status':12}"
        print(heading)
        billtotal=0
        for row in table:
            print('_'*150)
            billtotal += row['amount']
            temp = str(row['billdate'])
            temp = temp[0:10]
            row['billdate'] = dc.ConvertDatetoDMY(temp)
            if row['status']==1:
                row['status'] = 'paid'
            else:
                row['status'] = 'unpaid'
            output =  f"{row['id']:7}|{row['name']:64}|{row['billdate']:12}|{row['amount']:12}|{row['status']:12}"
            print(output)
        print('_'*150)
        print(f"total bill amount {billtotal}")
        print('_'*150)
while 1:
    print('-'*100)
    print("Press 1 for Bill management")
    print("Press 2 for Product management")
    print("Press 0 for for exit")
    ModuleChoice = int(input("enter your choice "))
    if ModuleChoice==1:
        while 1:
            print("Press 1 to add product into bill")
            print("Press 2 to delete product from bill")
            print("Press 3 to view bill items of current bill")
            print("Press 4 to save & print bill")
            print("Press 5 to print bills between given dates")
            print("Press 6 to search for specific bill by name")
            print("Press 0 for for exit")
            BillChoice = int(input("enter your choice "))
            if BillChoice==1: 
                DisplayProduct()
                productid = int(input("Enter product id"))
                table = GetProductById(productid)
                if table==False:
                    print("Error occured.")
                else:
                    count = len(table)
                    if count==0: 
                        print("product id not found")
                    else:
                        #print(table)
                        row = table[0] #fetch first row 
                        print("Product found. Available stock = ",row['stock'])
                        quantity = int(input("Enter quantity"))
                        if quantity>row['stock']:
                            print("not enough stock.")
                        else:
                            # here we will run insert query on bill_product table.
                            sql = "insert into bill_product (productid,rate,quantity) values (%s,%s,%s)"
                            values = [productid,row['price'],quantity]
                            response = mydb.RunQuery(sql,values)
                            if response==True:
                                print("Product added into bill")
                            else:
                                print("error occured")
            elif BillChoice==2: 
                DisplayBillItems()
                itemid = int(input("Enter item id to delete item from bill"))
                count = GetItemById(itemid)
                if count==0:
                    print("Item not found in bill")
                else:
                    sql = "delete from bill_product where id=%s"
                    values = [itemid]
                    response = mydb.RunQuery(sql,values)
                    if response==True:
                        print("item deleted from bill")
                    else:
                        print("error occured")
            elif BillChoice==3: 
                DisplayBillItems()
            elif BillChoice==4: 
                DisplayBillItems()
                confirm = input("Are you sure you want to print bill (yes/no)")
                if confirm in ['yes','YES']:
                    name = input("Enter customer fullname")
                    iscash = input("is this cash bill(yes/no)")
                    status = 1
                    if status not in ['yes','YES']:
                        status = 2
                    sql = "select sum(quantity*rate) 'total' from bill_product where billid=%s"
                    values = [0]
                    table = mydb.FetchRow(sql,values)
                    total = table[0]['total']
                    sql = "insert into bill (name,amount,status) values (%s,%s,%s)"
                    values = [name,total,status]
                    response = mydb.RunQuery(sql,values)
                    if response==True:
                        billid = mydb.sqlcommand.lastrowid
                        sql = "update bill_product set billid=%s where billid=%s"
                        values = [billid,0]
                        response = mydb.RunQuery(sql,values)
                        if response==True:
                            sql = "select productid,quantity from bill_product where billid=%s"
                            values = [billid]
                            table = mydb.FetchRow(sql,values)
                            for row in table:
                                sql = "update product set stock=stock-%s where id=%s"
                                values = [row['quantity'],row['productid']]
                                mydb.RunQuery(sql,values)
                            print("Bill Generated...")
                        else:
                            print("error occured")
                    else:
                        print("error occured") 
            elif BillChoice==5: 
                #SELECT * FROM `bill` WHERE date(`billdate`)>='2022-02-17' and date(`billdate`)<='2022-02-19'
                start_date=input("enter start date (DD-MM-YYYY)")
                end_date=input("enter end date (DD-MM-YYYY)")
                start_date = dc.ConvertDatetoYMD(start_date)
                end_date = dc.ConvertDatetoYMD(end_date)
                sql = "SELECT * FROM `bill` WHERE date(`billdate`)>=%s and date(`billdate`)<=%s"
                values = [start_date,end_date]
                table = mydb.FetchRow(sql,values)
                get_bill(table)
            elif BillChoice==6: 
                PersonName = input("Enter customer name")
                sql = "SELECT * FROM `bill` WHERE name=%s"
                values = [PersonName]
                table = mydb.FetchRow(sql,values)
                get_bill(table)
            elif BillChoice==0:
                break #it will break to outer while loop 
            else:
                print("Invalid choice")
    elif ModuleChoice==2:
        while 1:
            print("Press 1 to Add new product")
            print("Press 2 to Update product")
            print("Press 3 to delete product")
            print("Press 4 to view all product")
            print("Press 0 for for exit")
            ProductChoice = int(input("enter your choice "))
            if ProductChoice==1: 
                print("enter new product details")
                print('-'*100)
                name = input("Enter name ")
                detail = input("Enter detail ")
                price = int(input("Enter price "))
                stock = int(input("Enter stock(quantity) "))
                sql = "insert into product (name,detail,stock,price) values (%s,%s,%s,%s)"
                values = [name,detail,stock,price]
                result = mydb.RunQuery(sql,values)
                if result==True:
                    print("Product Added")
                else:
                    print("Error occured.")
            elif ProductChoice==2: 
                DisplayProduct()
                productid = int(input("Enter product id to update it"))
                name = input("Enter name ")
                detail = input("Enter detail ")
                price = int(input("Enter price "))
                stock = int(input("Enter stock(quantity) "))
                sql = "update product set name=%s,detail=%s,stock=%s,price=%s where id=%s"
                values = [name,detail,stock,price,productid]
                result = mydb.RunQuery(sql,values)
                if result==True:
                    print("Product updated")
                else:
                    print("Error occured.")
            elif ProductChoice==3: 
                DisplayProduct()
                productid = int(input("Enter product id to update it"))
                sql = "update product set isDeleted=1 where id=%s"
                values = [productid]
                result = mydb.RunQuery(sql,values)
                if result==True:
                    print("Product deleted")
                else:
                    print("Error occured.")
            elif ProductChoice==4: 
                DisplayProduct()
            elif ProductChoice==0:
                break #it will break to outer while loop 
            else:
                print("Invalid choice")
    elif ModuleChoice==0:
        print("Good Bye")
        print('-'*100)
        break
    else:
        print("Invalid choice")
    
