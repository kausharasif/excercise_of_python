# database connectivity with mysql
from mysql import connector as con
from mysql.connector import ProgrammingError
from mysql.connector import InterfaceError
try:
    db = con.connect(host="localhost", user="root", passwd="",
                     database="kaushar", port="3308")
    print("Connection estaliblished....")
    sqlcommand = db.cursor(dictionary=True) #sqlcommand which will be used to execute queries 
    while 1:
        try:
            sql = "insert into category (title,detail,status) values(%s,%s,%s)"
            title = input("Enter category title")
            detail = input("Enter category detail")
            status = input("enter status 1 = available 0=not available")
            if status!="1":
                status=0
            values = [title,detail,status]
            sqlcommand.execute(sql,values) #it will execute query 
            db.commit() #save changes made by query permently in database (compulsory)
            print("Category Added")
            
            sql = "update category set title=%s,detail=%s,status=%s where id=%s"
            categoryid = input("Enter category id to update")
            title = input("Enter category title")
            detail = input("Enter category detail")
            status = input("enter status 1 = available 0=not available")
            values = [title,detail,status,categoryid]
            sqlcommand.execute(sql,values)
            print("Category Updated")
            
            sql = "delete from category where id=%s"
            categoryid = input("Enter category id to delete row")
            values = [categoryid]
            sqlcommand.execute(sql,values)
            print("category deleted")
            sql = "select * from category order by id desc"
            sqlcommand.execute(sql)
            table = sqlcommand.fetchall() #return 2 dimensional list where 1st dimension is row and 2nd dimension is columns 
            heading = f"{'id':2}|{'title':32}{'detail':64}{'status':1}"
            print(heading)
            for row in table:
                msg = f"{row['id']:2}|{row['title']:32}{row['detail']:64}{row['status']:1}"
                print(msg)
            break
        except ProgrammingError as e: #e has all detail about error such as error no, and description of error
            print("Error No ",e.errno)
            print("Error short description ",e.msg)
            print("Error full description ",e._full_msg)
            if e.errno == 1146 and 'category' in e.msg:
                #table category does not exist in database so we will create it
                sql = """create table category(
                    id int PRIMARY KEY AUTO_INCREMENT,
                    title varchar(64) not null,
                    detail varchar(512),
                    status int(1) default 1 )"""
                sqlcommand.execute(sql)
                db.commit()
                print("category table is created successfully")   
except ProgrammingError:
    print ("database connection failed please check ")
    print ("1) ensure database server is on")
    print ("2) check password and database name ")
except InterfaceError:
    print ("database connection failed")
    print ("verify username, port no")
