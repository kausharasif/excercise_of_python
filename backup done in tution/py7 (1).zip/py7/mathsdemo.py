#some import function in math module
import math 
value = float(input("Enter float value"))
print(f"value is {value}")
print("floor value ",math.floor(value))
print("ceil value ",math.ceil(value))

print("truncated value ",math.trunc(value))