'''
hiearchical level inheritance 
when we create more then one new class from one existing class it is called hiearchical inheritance 
'''
class person: #parent/super/base class 
    def talk(self):
        print("i can talk...")
    def walk(self):
        print("i can walk...")
class student(person): #derived/sub/child class 
    def read(self):
        print("I can read....")
    def write(self):
        print("I can write....")
    def WhatICanDo(self):
        super().walk() #calling parent class method 
        super().talk() #calling parent class method 
        self.read() #calling student class method 
        self.write() #calling student class method 
class teacher(person): #derived/sub/child class
    def teach(self):
        print("I can teach.....")
    def guide(self):
        print("I can guide......")
    def WhatICanDo(self):
        super().walk()
        super().talk()
        self.teach()
        self.guide()
    
s1 = student()
s1.WhatICanDo()

t1 = teacher()
t1.WhatICanDo()

p1 = person()
p1.walk()
p1.talk()
        