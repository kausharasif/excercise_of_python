#example of for loop
list = ['Apple','Banana','Mango','Pinapple','Kiwi','Cherry','Orange']
count=1
for item in list:
    print(item,end=' ')
    count=count+1
print()
print(f"total items = {count}")

country = "India"
for letter in country:
    print(letter,end=' ')
print("")

#print 0 to 9
for number in range(10):
    print(number)