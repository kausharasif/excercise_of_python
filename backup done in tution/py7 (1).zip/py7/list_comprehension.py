from numpy import number


#numbers=[] #empty list
# for i in range(1,11):
#     numbers.append(i)
numbers = [i for i in range(1,11)] #list comprehension
print(numbers)

#oddnumbers=[]
# for value in numbers:
#     if value%2==1:
#         oddnumbers.append(value)
oddnumbers = [value for value in numbers if value%2==1]      
print(oddnumbers)

fruits = ['apple','orange','pinapple','banana','custerd apple']
print(fruits)

# apples=[]
# for fruit in fruits:
#     if 'apple' in fruit:
#         apples.append(fruit)

apples = [value for value in fruits if 'apple' in value]
print(apples)

# groups = [] 
# for value in range(1,11):
#     temp=[]
#     for inner_value in range(1,6):        
#         temp.append(inner_value)
#     groups.append(temp)
groups = [[inner_value for inner_value in range(1,6)] for outer_value in range(1,11)]
print(groups)
# matrix = [[x for x in range(3)] for y in range(3)]
# print(matrix)