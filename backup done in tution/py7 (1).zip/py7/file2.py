#write a program to read data from given file
while 1:
    try:
        file_name = input("Enter file name")
        file = open(file_name,"r")
        content = file.read()
        print(content)
        file.close()
        break
    except FileNotFoundError:
        print(f"{file_name} no such file exists....")
    except PermissionError:
        print(f"{file_name} it is not file....")
