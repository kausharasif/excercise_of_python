class Student:
    def __init__(self,name,surname):
        self.name = name 
        self.surname = surname
    def getStudentDetail(self):
        print("name " + self.name)
        print("surname " + self.surname)
class sportsman:
    def __init__(self,sports,experience):
        self.sports = sports
        self.experience = experience 
    def getSportsmanDetail(self):
        print("sports " + self.sports)
        print("experience " + str(self.experience))
class candidate(Student,sportsman): #multiple inheritance 
    def __init__(self,name,surname,sports,experience,qualification,salary):
        #calling parent class constructor
        Student.__init__(self,name,surname)
        sportsman.__init__(self,sports,experience)
        self.salary = salary 
        self.qulification = qualification
    def detail(self):
        super().getStudentDetail()
        super().getSportsmanDetail()
        print(f"salary " + str(self.salary))
        print("qualification " + self.qulification)
s1 = Student("roy","sing")
s1.getStudentDetail()

s2 = sportsman("Cricket",2)
s2.getSportsmanDetail()

c1 = candidate("rahul","dravid","cricket",20,"B.Com",12500000)
c1.detail()