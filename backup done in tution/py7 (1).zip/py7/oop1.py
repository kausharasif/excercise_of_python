class person:
    #behaviour
    def walk(self):
        print("i can walk")
    def talk(self):
        print("i can talk")
    def dance(self,DanceType):
        print(f"i can do {DanceType}")
    def read(self,*languages): #aribtary 
        print(" i can read",end=' ')
        for language in languages:
            print(language,end=' ')
    def write(self,*languages):
        print(" i can write ",end=' ')
        for language in languages:
            print(language,end=' ')

#create object of person class 
#object = classname()
hanish = person()
ayush = person()

hanish.walk()
hanish.talk()
hanish.dance("western dance")
hanish.read("hindi","gujarati","english")

print("")
ayush.walk()
ayush.talk()
ayush.dance("break dance")
hanish.read("hindi","gujarati","english","sankrit")
