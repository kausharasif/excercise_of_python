from kaushar.MyFileOperation import FileOperation
from kaushar.MyFileOperation import DirectoryOperation

directory = DirectoryOperation()
myfile = FileOperation()

# #let us create directory
# DirectoryName = input("Enter directory name to create it")
# directory.create(DirectoryName)


# #let us get current working directory
# CurrentDirectoryName = directory.getcurrentworkingdir()
# print(f"Current Directory = {CurrentDirectoryName}")

# #let us change current working directory
# DirectoryName = input("Enter new current working directory name")
# directory.changecurrentdir(DirectoryName)

# # let us remove directory
# DirectoryName = input("Enter new directory name to remove it")
# directory.removedir(DirectoryName)

#let us create new file using file
FileName = input("Enter file name to create it")
myfile.create(FileName)
FileContent = input("Enter some content to write into file")
myfile.write(FileContent)
myfile.close()
myfile.open(FileName) 
temp = myfile.read()
print(temp)
