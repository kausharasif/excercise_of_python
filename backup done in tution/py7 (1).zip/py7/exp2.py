list = [1,'test',3,'exam',5,6,7,None,9,False]
#list = None
sum=0
average=0
count=0
try:
    for value in list:
        print(f"{value}")
        try:
            if value!=None and value!=False:
                sum = sum + value
                count = count + 1
        except TypeError:
            print(f"invalid value = {value} so it is skiped")
    try:
        average = sum/count
        print(f"sum = {sum} average = {average}")
    except ZeroDivisionError:
        print("totally invalid value")
except TypeError:
        print("it is not a list at all")