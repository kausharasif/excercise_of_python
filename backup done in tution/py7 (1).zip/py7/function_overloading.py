class shape:
    def getArea(self,length=None,width=None):
        print(f"length = {length} width={width}")
        if length!=None and width!=None:
            return length * width
        elif length!=None:
            return length * length
        else:
            return 0       
s1 = shape()
print("area=" + str(s1.getArea()))
print("area= " + str(s1.getArea(10)))
print("area=" + str(s1.getArea(10,20)))