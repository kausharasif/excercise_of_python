class shape:
    def getPi(self):
        return 3.14
    
class MyMath:
    def getSquare(self,number):
       temp =  number * number
       return temp

class circle(shape,MyMath): #multiple inheritance 
    def __init__(self,radius):
        self.radius = radius
       
    def getArea(self):
        return super().getPi() * super().getSquare(self.radius);

radius = int(input("Enter radius"))    
c1 = circle(radius)
area = c1.getArea()
print(f"area of circle is = {area}")
