'''
hiearchical level inheritance 
when we create more then one new class from one existing class it is called hiearchical inheritance 
'''
class person: #parent/super/base class 
    def talk(self):
        print("i can talk...")
    def walk(self):
        print("i can walk...")
class student(person): #derived/sub/child class 
    def read(self):
        print("I can read....")
    def write(self):
        print("I can write....")
    def WhatICanDo(self):
        super().walk() #calling parent class method 
        super().talk() #calling parent class method 
        self.read() #calling student class method 
        self.write() #calling student class method 
class teacher(person): #derived/sub/child class
    def teach(self):
        print("I can teach.....")
    def guide(self):
        print("I can guide......")
    def WhatICanDo(self):
        super().walk()
        super().talk()
        self.teach()
        self.guide()
class citizen(student,teacher):
    def vote(self):
        print("I can do voting")
    def pay(self):
        print("I can pay tax")
    #method overriding(when parent and child class has same method (name & argumetns are same) it is called method overriding)
    def WhatICanDo(self):
        student.WhatICanDo(self)
        teacher.WhatICanDo(self)
        self.vote()
        self.pay()
c1 = citizen()
c1.WhatICanDo()
        