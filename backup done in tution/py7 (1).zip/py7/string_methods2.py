list = ['apple','banana','mango','orange','pinapple']
line = "__"
line = line.join(list)
print(line)

colors = "white black red green blue pink yellow"
colorlist = colors.split(" ")
print(colorlist)

sentence = "apple is red and apple is sweet"
print(sentence.replace("apple","cherry"))
