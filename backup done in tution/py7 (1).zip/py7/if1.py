#example of if statement in python 
#write a program to generate square of given positive number 
number = input("Enter positive number")
number = int(number) 
if number<0:
    print("number is negative so we have to convert into positive number")
    number = 0 - number 
    
square = number * number
print(f"square of {number} is = {square}")