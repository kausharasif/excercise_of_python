#write a program to print name of given month number without using decision making statement in python 
#input 1 = January 
month = int(input("Enter month number (between 1 to 12)"))
list = ['','January','February','March','April','May','June','July','Augest','September','Octomber','November','December']
if month>=1 and month<=12:
    print(list[month])
else:
    print("Invalid Month Number")
    