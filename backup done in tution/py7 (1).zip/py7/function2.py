def interest(amount,rate=12,year=1):
    result = (amount * rate * year)/100
    return result

a = int(input("Enter Amount"))
r = int(input("Enter Rate"))
y = int(input("Enter year"))

answer = interest(a,r,y) #0 argument default
print(f"interest is {answer}")

answer = interest(a,r) #1 argument default (year)
print(f"interest is {answer}")

answer = interest(a) #2 argument default 
print(f"interest is {answer}")

#calling function using keyword arguments
answer = interest(year=y,amount=a,rate=r)
print(f"interest is {answer}")

