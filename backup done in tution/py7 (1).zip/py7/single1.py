#single level inheritance 
class person: #parent/super/base class 
    def talk(self):
        print("i can talk...")
    def walk(self):
        print("i can walk...")
class student(person): #derived/sub/child class 
    def read(self):
        print("I can read....")
    def write(self):
        print("I can write....")
    def WhatICanDo(self):
        super().walk() #calling parent class method 
        super().talk() #calling parent class method 
        self.read() #calling student class method 
        self.write() #calling student class method 
s1 = student()
s1.WhatICanDo()
        