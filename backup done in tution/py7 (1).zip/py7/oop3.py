class room:
    #constructor 
    def __init__(self,length,width,deapth):
        print("constructor is called....")
        self.length = length #self. it will create instance variable 
        self.width = width 
        self.deapth = deapth 
    #normal methods 
    def getArea(self):
        #creating local variable
        area = self.width * self.length   
        return area 
    def getVolume(self):
        #local variable
        volume = self.width * self.length * self.deapth
        return volume
    
height = int(input("enter height"))
width = int(input("enter width"))
length = int(input("enter length"))

#create object of room class 
#object = class()
r1 = room(height,width,length) 
area = r1.getArea()
volume = r1.getVolume()
print(f"r1 area = {area} volume = {volume}")

height = int(input("enter height"))
width = int(input("enter width"))
length = int(input("enter length"))

r2 = room(height,width,length) 
area = r2.getArea()
volume = r2.getVolume()
print(f"r2 area = {area} volume = {volume}")