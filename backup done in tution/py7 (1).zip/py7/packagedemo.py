import india.gujarat.district as gj
import india.maharastra.district as mh 

print("Gujarat district list")
print(gj.getdistrict())

print("Maharastra district list")
print(mh.getdistrict())

