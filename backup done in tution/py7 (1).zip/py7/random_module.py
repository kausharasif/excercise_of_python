import random as rd 

print("One Random number between 0.0 to 1.0 ",rd.random())
print("One Random number between 1 to 100 ",rd.randint(1,100))
print("One Random number between 1 to 100 with step size 10 ",rd.randrange(1,100,10))
print("One Random number between 1 to 100 with step size 10 ",rd.randrange(1,100,10))

fruits = ['apple','banana','mango','pinapple','orange','kiwi']
print(fruits)
new_fruits = rd.sample(fruits,k=4)
print("only 4 fruits from new fruits")
print(new_fruits)
rd.shuffle(fruits)
print("Shuffled list")
print(fruits)
print("Any two fruit from list",rd.choices(fruits,k=2))