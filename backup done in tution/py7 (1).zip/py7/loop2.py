#write a program to print following pattern 
#1 4 9 16 25 36 79 64 ....... 100
count=1

while count<=10:
    square=count * count #1
    print(f" {square} ",end='') #1 
    count=count+1 #2





