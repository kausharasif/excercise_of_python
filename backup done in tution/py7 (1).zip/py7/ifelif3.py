#write a program to findout largest rectangle from 3 rectange using given height and width 

height1 = float(input("Enter height for 1st rectangle"))
width1 = float(input("Enter width for 1st rectangle"))

height2 = float(input("Enter height for 2nd rectangle"))
width2 = float(input("Enter width for 2nd rectangle"))

height3 = float(input("Enter height for 3rd rectangle"))
width3 = float(input("Enter width for 3rd rectangle"))

area1 = height1 * width1
area2 = height2 * width2
area3 = height3 * width3

if area1>area2: #first level
    if area1>area3: #second level 
        print(f"first rectangle is biggest rectangle and size is {area1}")
    else:
        print(f"third rectangle is biggest rectangle and size is {area3}")
else:
    if area2>area3:
        print(f"second rectangle is biggest rectangle and size is {area2}")
    else:
        print(f"third rectangle is biggest rectangle and size is {area3}")
        
print("good bye..")
        