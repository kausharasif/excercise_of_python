#concept of arbitary arguments
def sum(*numbers):
    total=0
    for value in numbers:
        total=total + int(value)
    return total 

total = sum(10,20)
print(f"total = {total}")

total = sum(100,200,400,800,1600,3200)
print(f"total = {total}")


total = sum(100,200,400)
print(f"total = {total}")
