#example of if statement in python 
#write a program to accept name from user and display greeting message if name is not blank 
name = input("Enter your name")
if name!='': 
    print(f"Welcome Mr/Miss/Mrs {name}")
print("Good Bye...")