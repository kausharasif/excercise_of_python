FileName = input("Enter FileName to read it's content")
mode = "r" # r/w/a/r+/w+/a+
try:
    file = open(FileName,mode)
    length=0
    count=-1
    for line in file:
        print(line,end='')
        length+=len(line)
        count+=1
    file.close()
    length+=count
    print("")
    print(f"file size = {length}")
except FileNotFoundError:
    print(f"File does not exist {FileName}")
except PermissionError:
    print(f"{FileName} is directory not a file")
    