add = lambda num1,num2: num1 + num2
sub = lambda num1,num2: num1 - num2 
mul = lambda num1,num2: num1 * num2 
div = lambda num1,num2: num1 / num2 
cube = lambda num1: num1 * num1 * num1

value1 = int(input("Enter first value"))
value2 = int(input("Enter second value"))


result = add(value1,value2) #calling lambda
print(f"addition = {result}")

result = sub(value1,value2)
print(f"substraction = {result}")

print(mul(value1,value2))
print(div(value1,value2))

print("cube = ", cube(value1))