from bs4 import BeautifulSoup 
HtmlDocument = "<html><head><title>this is page</title></head><body><h1>Page title </h1><p>this is 1st paragraph</p><p>this is 2nd paragraph</p><p>this is 3rd paragraph</p></p><p class='favourite'>this is favourite paragraph</p></body</html>"
page = BeautifulSoup(HtmlDocument,'html.parser')
print(page.prettify())
#get title of the page 
print(page.title.get_text())

#get first paragraph 
print(page.p.get_text())

#get all paragraphs 
paragraphs = page.find_all('p')
for item in paragraphs:
    print(item.get_text())

favourite = page.find_all("p", class_="favourite")
print(favourite[0].get_text())