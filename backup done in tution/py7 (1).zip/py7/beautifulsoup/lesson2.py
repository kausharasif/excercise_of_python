from bs4 import BeautifulSoup 
import requests

HtmlDocument = requests.get("https://www.prokerala.com/astrology/horoscope/?sign=aries")
page = BeautifulSoup(HtmlDocument.text,'html.parser')
#print(page.prettify())
# #get title of the page 
print(page.title.get_text())
content = page.find("article")
print(content.get_text())
