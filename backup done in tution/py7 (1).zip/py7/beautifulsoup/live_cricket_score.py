from turtle import pos, position
from bs4 import BeautifulSoup 
import requests
HtmlDocument = requests.get("https://www.espncricinfo.com/live-cricket-score")
page = BeautifulSoup(HtmlDocument.text,'html.parser')
print(page.title.get_text())
row = page.find("div", class_="container-fluid").find("div",class_="row")
blocks = row.find_all("div",class_="col-md-8 col-16")
for block in blocks:
    divs = block.find("div",class_="match-score-block")
    position=0;
    for div in divs:
        if position==1:
            match_info = div.find("a").find("div").find("div")
            for info in match_info:
                print(info.get_text())
        position+=1
    print('-'*50)