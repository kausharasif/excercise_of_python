from bs4 import BeautifulSoup 
import requests
list = ['aries', 'taurus', 'gemini', 'cancer', 'leo', 'virgo', 'libra', 'scorpio', 'sagittarius', 'capricorn', 'aquarius', 'pisces']
zodiac_sign = input("What is your zodiac sign?")
if zodiac_sign in list:
    HtmlDocument = requests.get(f"https://www.prokerala.com/astrology/horoscope/?sign={zodiac_sign}")
    page = BeautifulSoup(HtmlDocument.text,'html.parser')
    #print(page.prettify())
    # #get title of the page 
    print(page.title.get_text())
    content = page.find("article")
    print(content.get_text())
else:
    print("invalid zodiac sign")