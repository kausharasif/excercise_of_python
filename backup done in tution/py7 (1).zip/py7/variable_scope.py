amount = 1000 #global variable
def AddMoney(addition):
    amount=0 #local variable
    amount = amount + addition #it will change local variable 
addition = int(input("enter amount"))
print(f"before addition amount = {amount}")
AddMoney(amount)
print(f"after addition amount = {amount}")