amount = 1000 #global variable
def AddMoney(addition):
    global amount #in this function global amount variable will be accessed and changed
    amount = amount + addition #it will change global variable 
addition = int(input("enter amount"))
print(f"before addition amount = {amount}")
AddMoney(addition)
print(f"after addition amount = {amount}")