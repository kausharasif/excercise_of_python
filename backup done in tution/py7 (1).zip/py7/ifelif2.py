#write a program to develop bmi calculator using if elif ladder decision making statement 
weight = float(input("Enter your weight in KG"))
print("Enter your height (in foot and inch)")
foot = int(input("Enter only foot"))
inch = int(input("Enter only inches"))

#calculate bmi bmi = weight/(height_in_meter * height_in_meter)
height = (foot * 12 ) + inch 
height = height / 39.37
bmi = weight/(height * height)
print(f"your bmi is {bmi}")

if bmi>=35:
    print("you are extremely obese you should consult some good dietian")
elif bmi>=30:
    print("you are obese you should follow some diet plan")
elif bmi>=25:
    print("you are overwight you should exercise daily")
elif bmi>=18.5:
    print("you have perfect weight no need to do anything")
else:
    print("you are underweight and you should eat healthy food")
    