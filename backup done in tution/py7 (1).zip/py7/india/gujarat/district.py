def getdistrict():
    district = ['Bhavnagar','Junagadh','Gandhinagar','Ahmedbad','Surat','Baroda','Rajkot']
    return district