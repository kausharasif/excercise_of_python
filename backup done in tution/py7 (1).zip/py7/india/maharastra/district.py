def getdistrict():
    district = ['Pune','Nagpur','Kolhapur','Satara','Sangli','Bombay','akola']
    return district