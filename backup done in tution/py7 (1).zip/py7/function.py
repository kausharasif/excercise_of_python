#example of user defined functions in python 
def getabs(number): #-5
    #return positive value of given value if value is negative
    number = int(number)
    if number<0:
        #negative number 
        number = 0 - number;
    return number
def getsquare(number):
    number = getabs(number)
    answer = number * number
    return answer
number = input("Enter one number")
answer = getsquare(number)
print(f"answer is {answer}")