import time 
from datetime import datetime
current_timestamp = time.time() # time() of time return current timestamp
current_timestamp = int(current_timestamp)
print(current_timestamp)
#findout difference between local time & utc time
from datetime import datetime
local = datetime.now()
utc = datetime.utcnow()
difference = round((local - utc).seconds, -1)
#convert timestamp to date 
date_time = datetime.utcfromtimestamp(current_timestamp + difference)
current_date = date_time.strftime("%d-%m-%Y %H:%M:%S")
print(current_date)


