#multi level inheritance 
class kb: #parent/super/base class
    def __init__(self,bytes):
        print("kb class constructor is called...")
        self.bytes = bytes 
    def getKB(self):
        temp = self.bytes // 1024
        return temp 
class mb(kb): #child/sub/derived class
    def __init__(self,bytes):
        #call parent class constructor from child class constructor
        super().__init__(bytes)
        print("mb class constructor is called....")
    def getMB(self):
        temp = super().getKB() / 1024
        return temp
class gb(mb):
    def __init__(self,bytes):
        super().__init__(bytes)
        print("gb class constructor is called....")
    def getGB(self):
        temp = super().getMB() / 1024
        return temp 
bytes = int(input("Enter bytes"))
g1 = gb(bytes)
result = g1.getGB()
print(f"gb = {result}")

