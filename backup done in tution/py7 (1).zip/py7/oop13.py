#hybrid level inheritance 
class shape:
    def getPi(self):
        return 3.14
    def getSquare(self,number):
       temp =  number * number
       return temp
class circle(shape): 
    def __init__(self,radius):
        self.radius = radius
    def getArea(self):
        return super().getPi() * super().getSquare(self.radius);
class cyliender(shape):
    def __init__(self,radius,height):
        self.radius = radius 
        self.height = height 
    def getArea(self):
        temp = (2 * super().getPi() * self.radius * self. height) + 2 * super().getPi() * super().getSquare(self.radius)
        return temp  
class CompareCyliender(cyliender):
    def __init__(self,radius,height):
        super().__init__(radius,height)
        print("CompareCyliender class constructor called... ")
    def compare(self,c2):
        area1 = super().getArea()
        area2 = c2.getArea()
        if area1>area2:
            return True 
        else:
            return False
print("Enter first cyliender detail")
radius = int(input("Enter radius"))
height = int(input("Enter height"))
c1 = CompareCyliender(radius,height)

print("Enter second cyliender detail")
radius = int(input("Enter radius"))
height = int(input("Enter height"))
c2 = CompareCyliender(radius,height)

print("c1 cyliender area " + str(c1.getArea()))
print("c2 cyliender area " + str(c2.getArea()))

result = c1.compare(c2);
if result==True:
    print("C1 is bigger")
else:
    print("C2 is bigger")