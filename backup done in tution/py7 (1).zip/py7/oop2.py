class mail:
    def compose(self,subject,body,recipent):
        self.subject = subject # self.subject create instance variable
        self.body = body # self.subject create instance variable
        self.recipent = recipent # self.subject create instance variable
        print("email composed sucessfully....")
    def send(self):
        print(f"email sent to {self.recipent}")
        print(f"subject = {self.subject} body = {self.body}")
        
personal_mail = mail()
personal_mail.compose(subject="test mail",body="hello this message body",recipent=["hanish@gmail.com"])
personal_mail.send()

profession_mail = mail()
profession_mail.compose(subject="work mail",body="hello this work message body",recipent=["ankit@gmail.com"])
profession_mail.send()