#write a program to print 1 to 50 numbers on same line 
#1 2 3 4 .......50

count=1

while count<=50:
    print(f" {count} ",end='') #1
    count=count+1 #2

