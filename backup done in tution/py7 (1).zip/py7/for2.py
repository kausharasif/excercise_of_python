#example of reverse for loop 
list = ['Apple','Banana','Mango','Pinapple','Kiwi','Cherry','Orange']
for item in reversed(list):
    print(item)
    
print("Reversed number")
for number in range(9,0,-1):
    print(number)

print("odd number")
for number in range(1,11,2):
    print(number)