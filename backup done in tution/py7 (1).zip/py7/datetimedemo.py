from datetime import datetime

today = datetime.now()
print(f"today = {today}")

JustTime = datetime.time(datetime.now()) #just time
print(f"Only Time = {JustTime}")
hour = JustTime.hour 
minute = JustTime.minute 
print(f"Current time {hour} {minute}") 
#12 hour format
ampm = "am"
if hour>12:
    hour = hour - 12
    ampm = "pm"
print(f"Current time {hour} {minute} {ampm}") 
FullDateTime = str(today.day) + "," + str(today.month) + "," + str(today.year) + " " + str(today.hour) + ":" + str( today.minute) + ":" + str(today.second)
print(FullDateTime)