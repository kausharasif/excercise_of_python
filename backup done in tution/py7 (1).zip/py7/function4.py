#Arbitrary Argument Lists
def maximum(*values):
    max = values[0]
    for value in values:
        if max<value: #5
            max = value 
    return max #25

max = maximum(10,5,1,45,89,-45,215,165)
print(f"maximum = {max}")

max = maximum(10,5,1,45)
print(f"maximum = {max}")