#hiearchical level inheritance 
class shape:
    def getPi(self):
        return 3.14
    def getSquare(self,number):
       temp =  number * number
       return temp
class circle(shape): 
    def __init__(self,radius):
        self.radius = radius
    def getArea(self):
        return super().getPi() * super().getSquare(self.radius);
class cyliender(shape):
    def __init__(self,radius,height):
        self.radius = radius 
        self.height = height 
    def getArea(self):
        temp = (2 * super().getPi() * self.radius * self. height) + 2 * super().getPi() * super().getSquare(self.radius)
        return temp  
    

radius = int(input("Enter radius"))
height = int(input("Enter height"))

c1 = circle(radius)
print("Circle area " + str(c1.getArea()))

c2 = cyliender(radius,height)
print("Circle radius " + str(c2.getArea()))
