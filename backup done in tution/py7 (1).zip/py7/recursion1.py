#write a program to print 1 to 10 in using recursion 
def print_numbers(number):
    number=number+1
    if number==11:
        return None
    else:
        print_numbers(number) #2 recursion
    print(number)
    
number=0
print_numbers(number)