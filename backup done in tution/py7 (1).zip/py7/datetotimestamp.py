import time 
from datetime import datetime
date = "12/07/1985"
timestamp = time.mktime(datetime.strptime(date,"%d/%m/%Y").timetuple())
print(timestamp)