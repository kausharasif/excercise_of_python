name = "TheeasyLearnacademy"
print(name.upper())
print(name)
print(name.lower())
print(name)
print("Length of string",len(name))
print(name)

if name.isalpha()==True:
    print("String has only alphabets")
    
if name.isalnum()==True:
    print("String has both alphabets and numbers")

if name.islower()==True:
    print("String is in lower case")
    
if name.isupper()==True:
    print("String is in uppercase")

if name.isnumeric()==True:
    print("String has only numbers")
    
if name.istitle()==True:
    print("String is in title case")