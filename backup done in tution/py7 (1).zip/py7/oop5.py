#single level inheritance 
'''
when we create one new class from one existing class it is known as single level
inheritance.
'''
class kb: #parent/super/base class
    def __init__(self,bytes):
        print("kb class constructor is called...")
        self.bytes = bytes 
    def getKB(self):
        temp = self.bytes // 1024
        return temp 
class mb(kb): #child/sub/derived class
    def __init__(self,bytes):
        #call parent class constructor from child class constructor
        super().__init__(bytes)
        print("mb class constructor is called....")
    def getMB(self):
        temp = super().getKB() // 1024
        return temp
    
bytes = int(input("Enter bytes"))
k1 = kb(bytes)
result = k1.getKB()
print(f"Kilo bytes of given bytes = {result}")
m1 = mb(bytes)
result = m1.getMB()
print(f"mega bytes of given bytes = {result}")
