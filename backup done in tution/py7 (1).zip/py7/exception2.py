#write a program to findout & display qube of positive given number
while 1: #infinite loop (never stop )
    try:
        number = int(input("Enter positive number to findout its qube")) 
        if number<0: #< > <= >= == !=
            print("you have entered negative number")
            number = 0 - number # 0 - -10
        qube = number * number * number 
        print(f"qube = {qube}")
        break #stop loop 
    except ValueError:
        print("invalid input only numbers are allowed")
print("Good Bye..")