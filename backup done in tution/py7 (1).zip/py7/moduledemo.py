import mymodule #import module from current directory
import armstrong_module as arm #arm is an alias that we can use to call method of the module
#import module from directory whose path is given in PYTHONPATH directory
number = int(input("Enter number"))
answer = mymodule.getSquare(number);
print(f"answer of square {answer}")
answer = mymodule.getQube(number)
print(f"answer of qube {answer}")

number = int(input("Enter number to check whether the given number is armstrong number or not "))
arm.isArmStrong(number)

