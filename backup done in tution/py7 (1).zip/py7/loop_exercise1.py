# 2) print following pattern using while loop 
# 1   3   5   7   9   11  99
number = 1

while number<=99:
    reminder = number % 2
    if reminder!=0: #odd
        print(number)
    number=number+1 #2





