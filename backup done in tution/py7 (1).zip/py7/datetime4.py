from datetime import datetime 
timestamp = 125122122
print(timestamp)
date_time = datetime.fromtimestamp(timestamp)
print(date_time)