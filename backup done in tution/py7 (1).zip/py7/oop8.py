#example of multilevel inheritance
'''
when we create new class from derived class then it is called multilevel inheritance 

'''
class person: #parent/super/base class 
    def talk(self):
        print("i can talk...")
    def walk(self):
        print("i can walk...")
class student(person): #derived/sub/child class 
    def read(self):
        print("I can read....")
    def write(self):
        print("I can write....")
class developer(student):
    def code(self):
        print("I can write code in python")
    def debug(self):
        print("I can debug code written into python language")
    def WhatCanIDo(self):
        super().walk()
        super().talk()
        super().read()
        super().write()
        self.code()
        self.debug()
kishan = developer()
kishan.WhatCanIDo()