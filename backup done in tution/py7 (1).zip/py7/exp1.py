#write a program to findout whether given number is prime number or not 
#input = 5
#output = its prime number 

#input = 2244
#output = its not prime number 
while 1:
    try:
        number = int(input("Enter number to check is it prime or not"))
        divisor = 2
        while divisor<number: #15
            reminder=number%divisor
            if reminder==0:
                print("its is not prime number")
                break
            else:
                divisor=divisor+1
        if divisor==number:
            print("Its prime number")
        break; #terminate loop 
    except ValueError:
        print("invalid input, only number is allowed input")