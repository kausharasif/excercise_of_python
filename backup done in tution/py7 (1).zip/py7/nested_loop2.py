#write a program to print first 20 armstrong number 
'''
A positive integer of n digits is called an Armstrong number of order n (order is number of digits) if. 
abcd... = pow(a,n) + pow(b,n) + pow(c,n) + pow(d,n) + .... 
example 
#number = 153
process = 1^3 + 5^3 + 3^3 = 153
#number = 2
process = 2^1 = 2
'''
import math
number = 1
armstrong_counter=0
while armstrong_counter<=20:
    size = len(str(number)) # 3
    copy_number = number
    answer=0
    while number>0:
        reminder = number % 10 #3
        power = math.pow(reminder,size) # 3x3x3 =27
        answer = answer + power #27
        number = int(number/10) #15
    if copy_number==answer:
        print(f"{copy_number} ")
        armstrong_counter=armstrong_counter+1
    copy_number=copy_number+1
    number=copy_number







