list = [10, 20, 40, 80, 160, 320, 640, 1280]
print(list)
while 1:
    try:
        position = int(input("Enter position to print value from list"))
        print("value at position = ", position, " = ", list[position])
        #print(message)
    except IndexError as error:
        print("no such position in list")
        print(error)
    except ValueError as error:
        print("invalid input only numbers are allowed")
        print(error)
    except NameError as error:
        print("variable does not exists...")
        print(error)
        break
    else:
        print("Program executed sucessfully...")
        break
