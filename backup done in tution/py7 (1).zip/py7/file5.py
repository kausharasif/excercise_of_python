import os 
while 1:
    try:
        ExistingFileName = input("Enter File Name to rename it") 
        NewFileName = input("Enter new filename ")
        os.rename(ExistingFileName,NewFileName)
        print("File renamed successfully...") 
        break
    except FileNotFoundError:
        print("file does not exists " + ExistingFileName)
        response = input("Do you want to retry? Yes/No")
        if response=="Yes":
            continue
        else:
            break
    except PermissionError:
        print("you dont have permission to rename file ");
        response = input("Do you want to retry? Yes/No")
        if response=="Yes":
            continue
        else:
            break
print("Good bye...")