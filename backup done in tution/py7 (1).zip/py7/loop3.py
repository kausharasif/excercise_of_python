#write a program to findout factorial of given number 
#input=5
#process = 5 x 4 x 3 x 2 x 1 = 120 
#output 120 

number = int(input("Enter number to findout its factorial")) #5
multiplier = 1
answer = 1

while multiplier<=number:
    answer = answer * multiplier #1
    multiplier= multiplier + 1 #2
    
    # answer = answer * multiplier #1
    # multiplier= multiplier + 1 #2
    
    # answer = answer * multiplier #1
    # multiplier= multiplier + 1 #2
    
    # answer = answer * multiplier #1
    # multiplier= multiplier + 1 #2
print(f"factorial of {number} = {answer}")



