class student:
    ClassName = "the easylearn acacdemy" #class variable
    def __init__(self,rollno,name):
        self.rollno = rollno
        self.name = name 
    def display(self):
        print("Roll No ",self.rollno)
        print("Name ",self.name)

s1 = student(100,"Kishan vora")
s2 = student(101,"Hanish dhamecha")

s1.display()
s2.display()
print("S1 Student Institute ",s1.ClassName)
print("S2 Student Institute ",s2.ClassName)
print("Student Institute ",student.ClassName)
student.ClassName = "TEA" #it will change ClassName for all objects
print("S1 Student Institute ",s1.ClassName)
print("S2 Student Institute ",s2.ClassName)
print("Student Institute ",student.ClassName)

s1.ClassName = "THE EASYLEARN ACADEMY, BHAVNAGAR"
#if we change class variable using object then it become instance variable for that object
print("S1 Student Institute ",s1.ClassName)
print("S2 Student Institute ",s2.ClassName)
print("Student Institute ",student.ClassName)
print("Show s1 object detail....")

print("S1 student Name ",s1.name)
print("S1 student rollno ",s1.rollno)