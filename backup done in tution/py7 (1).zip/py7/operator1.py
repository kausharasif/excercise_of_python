#example of arithmetic operator 
number1 = input("Enter first number")
number2 = input("Enter second number")
number1 = int(number1)
number2 = int(number2)
addition = number1 + number2
substraction = number1 - number2
multiplication = number1 * number2
division = number1 / number2
reminder = number1 % number2
floor_division = number1 // number2
power = number1 ** number2

output = f"addition = {addition} substraction={substraction} multiplication={multiplication} division={division} reminder={reminder} floor division = {floor_division} power = {power}"

print(output)
