#write a program to convert decimal number into binary number 
def binary(number):
    if number>0:
        reminder = number % 2
        number = int(number/2)
        binary(number)
        print(reminder,end=' ')
    else:
        return None

number = int(input("Enter number"))
binary(number)