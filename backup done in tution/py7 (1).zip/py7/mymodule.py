def getSquare(number):
    return number * number
def getQube(number):
    return getSquare(number) * number
