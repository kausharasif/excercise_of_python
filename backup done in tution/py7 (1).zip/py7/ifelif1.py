#program for if elif else statement 
#write a program to print name of given month number 
#input 1 = January 
month = int(input("Enter month number (between 1 to 12)"))
if month==1:
    print("Its January ")
elif month==2:
    print("Its February")
elif month==3:
    print("Its March")
elif month==4:
    print("Its April")
elif month==5:
    print("Its May")
elif month==6:
    print("Its June")
elif month==7:
    print("Its July")
elif month==8:
    print("Its Augest")
elif month==9:
    print("Its September")
elif month==10:
    print("Its October")
elif month==11:
    print("Its November")
elif month==12:
    print("Its December")
else:
    print("Invalid month number")
    