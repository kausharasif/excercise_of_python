import time 
from datetime import datetime
date1 = input("Enter date in d/m/Y format")
timestamp1 = time.mktime(datetime.strptime(date1,"%d/%m/%Y").timetuple())
print(timestamp1)

date2 = input("Enter another date in d/m/Y format")
timestamp2 = time.mktime(datetime.strptime(date2,"%d/%m/%Y").timetuple())
print(timestamp2)
if timestamp1<timestamp2:
    print("first date is older date")
else:
    print("second date is older date")