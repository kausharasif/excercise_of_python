#write a program to findout & display qube of positive given number
try:
    number = int(input("Enter positive number to findout its qube")) 
    if number<0: #< > <= >= == !=
        print("you have entered negative number")
        number = 0 - number # 0 - -10
    qube = number * number * number # 10 * 10
    print(f"qube = {qube}")
except ValueError:
    print("invalid input only numbers are allowed")
