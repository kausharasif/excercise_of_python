import os
while 1: 
    try:
        FileName = input("Enter File Name to remove it")
        os.remove(FileName)
        print("File removed successfully...")
        break
    except FileNotFoundError:
        print("file does not exists " + FileName)
        response = input("Do you want to retry? Yes/No")
        if response=="Yes":
            continue
        else:
            break
    except PermissionError:
        print("you dont have permission to delete file ");
        response = input("Do you want to retry? Yes/No")
        if response=="Yes":
            continue
        else:
            break
print("Good bye...")