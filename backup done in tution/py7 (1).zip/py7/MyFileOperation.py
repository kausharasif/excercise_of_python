import os
import shutil
class DirectoryOperation:
    def create(self,DirectoryName): #c:\india\gujarat\bhavnagar
        isError = True
        try:
            os.makedirs(DirectoryName)
            print("Directory created")
            isError = False 
        except FileNotFoundError:
            print("Path is invalid")
        except FileExistsError:
            print("Directory already exists")
        return isError
    def getcurrentworkingdir(self):
        temp = os.getcwd() # cwd = Current working directory, dir = directory
        return temp 
    def changecurrentdir(self,DirectoryName):
        try:
            os.chdir(DirectoryName)
            print(f"now your current working directory is {DirectoryName}")
            return True
        except FileNotFoundError:
            print("Directory does not exist")
            return False
    def removedir(self,DirectoryName):
        try:
            os.rmdir(DirectoryName) #remove directory if empty otherwise error
            print("Directory removed")
            return True
        except FileNotFoundError:
            print(f"{DirectoryName} does not exists...")
            return False
        except OSError:
            print(f"{DirectoryName} is not empty...")
            response = input("Are you want to delete directory with its content (yes/no)")
            if response=="yes":
                shutil.rmtree(DirectoryName)
                print("Directory removed...")
                return True
            else:
                return False
class FileOperation:
    def __init__(self):
        self.fn = None #fn = filename
        print("constructor called...")
    def create(self,FileName):# it is used create file
        self.fn = open(FileName,"w")
        print(f"File created {FileName}")
    def open(self,FileName,mode='r'):
        try:
            self.fn = open(FileName,mode) #calling library function open
            print(f"File opened {FileName}")
            return True
        except FileNotFoundError:
            print(f"File {FileName} does not exist")
            return False
    def read(self): #it used to read content from file 
        if self.fn == None:
            return None
        else:
            FileContent = ""
            for line in self.fn:
                FileContent = FileContent + line
            return FileContent 
    def close(self): #it is used to close file
        if self.fn!=None:
            self.fn.close() #calling library function close
    def write(self,Content): #it is used to write content into file
         if self.fn==None:
             return False
         else:
             self.fn.write(Content)
             print("File saved")
             return True
    def append(self,Content): #it is used to append content at the end of file
        if self.fn==None:
            return False 
        else:
            self.fn.write(Content)
            return True
    def rename(self,OldFileName,NewFileName):
        try:
            os.rename(OldFileName,NewFileName)
            print("File name changed")
            return True
        except FileNotFoundError:
            print("File does not exists")
            return False
    def delete(self,ExistingFileName):
        try:
            os.remove(ExistingFileName)
            print("File deleted")
            return True
        except FileNotFoundError:
            print("File does not exists")
            return False  
        except PermissionError:
            print("either you do not have to permission to delete file. or it is not file")
            return False  