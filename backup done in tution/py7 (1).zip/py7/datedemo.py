from datetime import date 

current_date = date.today()
print(f"Current date = {current_date}")

#indian format 
indian_format = str(current_date.day) + "-" + str( current_date.month) + "-" + str(current_date.year )

#us format 
us_format = str(current_date.month) + "-" + str(current_date.day) + "-" + str(current_date.year)

print(f"indian format = {indian_format}")
print(f"us format = {us_format}")

weekday = current_date.weekday(); #return current of day in week as number
print(f"today is {weekday} of week")
days = ['monday','tuesday','wednesday','thursday','friday','saturday','sunday']
print(days[weekday])