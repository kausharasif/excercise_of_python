#get current date and time 
from datetime import datetime

now = datetime.now()
print(now)

day = now.strftime("%d")
month = now.strftime("%m")
year = now.strftime("%Y")
hour = now.strftime("%H")
minute = now.strftime("%M")
second = now.strftime("%S")
print(day + "/" + month + "/" + year + " " + hour + ":" + minute + ":" + second)