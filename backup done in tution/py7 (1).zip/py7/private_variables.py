#concept of private variable
class person: #parent/super/base class 
    def __init__(self,id,name):
        #create private variable (you cant access this variable from child class)
        self.__id = id
        self.name = name #normal instance variable
    def talk(self):
        print("i can talk...")
    def walk(self):
        print("i can walk...")
    def showid(self):
        print("person id = ",self.__id)
class student(person): #derived/sub/child class 
    def read(self):
        print("I can read....")
    def write(self):
        print("I can write....")
    def WhatICanDo(self):
        super().walk() #calling parent class method 
        super().talk() #calling parent class method 
        self.read() #calling student class method 
        self.write() #calling student class method 
        #trying to access private variable 
        #print("person id " + self.id) #want work
        print("person name " + self.name)
s1 = student(1,"Rahul")
s1.WhatICanDo()

p1 = person(2,"jay")
print("person name " + p1.name)
#print("person id " + p1.__id) private variable can not be accessed outside class