#example of if and else statement in python 
#write a program to accept two team cricket batting score from user and findout which team is winner 
team1_score = int(input("Enter first team score"))
team2_score = int(input("Enter second team score"))
if team1_score>team2_score: #< <= > >= == !=
    print("Team 1 is winner")
    print("Team 2 is looser")
else:
    print("Team 1 is looser")
    print("Team 2 is winner")

print("Best of luck for next match")