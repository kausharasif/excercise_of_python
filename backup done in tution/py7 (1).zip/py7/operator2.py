#example of shorthend assignment operator 
a = input("Enter first number")
b = input("Enter second number")
a = int(a)
b = int(b)
a+=b 
print(f"a={a} b={b}")
a-=b
print(f"a={a} b={b}")
a*=b 
print(f"a={a} b={b}")
a/=b
print(f"a={a} b={b}")
