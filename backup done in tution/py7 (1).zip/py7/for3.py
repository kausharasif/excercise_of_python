#write a program to print multiplication table of given number
'''
input : 2
2 x 1 = 2
2 x 2 = 2
'''
number = int(input("Enter number"))
for multiplier in range(1,11):
    answer = number * multiplier #2
    output = f"{number} x {multiplier} = {answer}"
    print(output) #2 x 1 = 2




